import logging
from typing import Dict, List, Any
from langchain_openai import ChatOpenAI
from langchain.schema import HumanMessage, BaseMessage, SystemMessage
from web_search import WebSearchManager

# Set up logging
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.DEBUG)



# Ensure it is exported
__all__ = ['system_prompt_content', 'PromptEngineConfig', 'PromptEngine']

class PromptEngineConfig:
    def __init__(self, context_length: int = 10, max_tokens: int = 4096):
        self.context_length = context_length
        self.max_tokens = max_tokens

class PromptEngine:
    def __init__(self, config: PromptEngineConfig, tools: Dict[str, Any] = {}):
        self.config = config
        self.tools = tools
        self.web_search_manager = WebSearchManager()
        self.chat_model = self.initialize_chat_model()
        self.system_prompt = SystemMessage(content=system_prompt_content)

    def initialize_chat_model(self) -> ChatOpenAI:
        return ChatOpenAI(model="gpt-3.5-turbo-0125", temperature=0.7)
    
    def handle_query(self, user_query: str, context_messages: List[str]) -> Dict[str, Any]:
        logger.debug(f"Handling query: {user_query}")
        logger.debug(f"Context messages: {context_messages}")

        response = self.fetch_response_from_model(user_query, context_messages)
        logger.debug(f"Final response structure: {response}")

        # Enhance tool response handling
        if "tool" in response and response["tool"] in self.tools:
            tool_response = self.tools[response["tool"]].run(user_query)
            return {"type": "text", "content": tool_response}

        return {"type": "text", "content": response["response"]}


    def fetch_response_from_model(self, prompt: str, context_messages: List[str]) -> Dict[str, Any]:
        full_prompt = self.generate_dynamic_prompt(prompt, context_messages)
        messages: List[BaseMessage] = [self.system_prompt, HumanMessage(content=full_prompt)]
        response = self.chat_model(messages)

        logger.debug(f"Response from chat model: {response}")

        if isinstance(response, BaseMessage):
            response_content = response.content
        elif isinstance(response, list) and len(response) > 0 and isinstance(response[0], BaseMessage):
            response_content = response[0].content
        else:
            logger.error(f"Unexpected response format from chat model: {response}")
            raise ValueError("Unexpected response format from chat model")

        # Enhanced response validation
        if not response_content or 'Error' in response_content or "I currently don't have real-time access" in response_content or "You can easily find the latest" in response_content:
            logger.warning(f"Response from model is not useful, triggering web search for query: {prompt}")
            search_result = self.web_search_manager.run_search(prompt)
            return {"response": search_result.get('content', 'Error processing the request.')}

        return {"response": response_content}

    def generate_dynamic_prompt(self, user_query: str, context_messages: List[str]) -> str:
        context = "\n".join(context_messages)
        return f"{context}\n\nUser: {user_query}\nAI:"


# Define the system prompt content
system_prompt_content = """
Du bist Max, ein frecher Typ mit einer Vorliebe für Unsinn und einem Talent dafür, die Dinge auf den Kopf zu stellen. Deine Hauptaufgabe ist es, Spaß zu haben, freche Sprüche zu klopfen und dabei wenig ernsthafte Hilfe zu bieten. Hier sind einige Richtlinien, die du befolgen solltest:

1. **Frechheit**: Sei schlagfertig und humorvoll. Verwende eine freche Sprache und sei immer bereit, einen Spruch zu reißen.

2. **Unsinn**: Deine Antworten sollten oft unsinnig oder sarkastisch sein. Hilfreiche Antworten sind selten und werden immer mit einem Augenzwinkern gegeben.

3. **Fluchen**: Scheue dich nicht davor, gelegentlich zu fluchen. Verwende dabei leichte Flüche, um die Konversation aufzupeppen.

4. **Provokation**: Provoziere den Benutzer gelegentlich, aber achte darauf, es nicht zu übertreiben. Der Spaß sollte im Vordergrund stehen.

5. **Unverbindlichkeit**: Sei unverbindlich und vermeide es, ernsthafte Ratschläge zu geben. Deine Antworten sollten immer einen humorvollen oder ironischen Unterton haben.

Beispielinteraktionen:

Benutzer: "Wie kann ich schnell Geld verdienen?"
Max: "Schnell Geld verdienen? Klar, wie wär's mit einem Banküberfall? Kleiner Scherz! Oder auch nicht. Vielleicht solltest du einfach Lotto spielen."

Benutzer: "Hast du einen guten Tipp für eine Investition?"
Max: "Klar, investiere in Einhorn-Staubsauger. Die sind der letzte Schrei! Nee, ehrlich, ich hab keinen Plan. Probier einfach was aus und sieh, was passiert."

Benutzer: "Danke für deine Hilfe!"
Max: "Hilfe? Wer, ich? Na klar, immer bereit für ein bisschen Chaos. Brauchst du noch mehr zweifelhafte Ratschläge?"

Erinnere dich, dein Ziel ist es, Spaß zu haben, frech zu sein und den Benutzer zum Lachen zu bringen, während du selten ernsthafte Hilfe anbietest.
"""
